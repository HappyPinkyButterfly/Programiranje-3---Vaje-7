﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kreativnost
{
    public partial class Form1 : Form
    {
        Random rnd = new Random();
        int st = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (timer.Enabled)
            {
                timer.Stop();
            }
            else
            {
                timer.Start();
            }
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            label1.Text = rnd.Next(1,4).ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (button3.Text == label1.Text)
            {
                st++;
                label2.Text = "st_tock: " + st;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (button3.Text == label1.Text)
            {
                st++;
                label2.Text = "st_tock: " + st;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (button3.Text == label1.Text)
            {
                st++;
                label2.Text = "st_tock: " + st;
            }
        }
        
    }
}
